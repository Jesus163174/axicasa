<?php $__env->startSection('title','Registro de usuarios'); ?>
<?php $__env->startSection('breadcrum'); ?>
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/empleados">Empleados</a></li>
    <li class="active">Registro</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <form action="<?php echo e(asset('empleados')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="panel panel-primary">
                <div class="panel-heading">
                    <h3 class="panel-title">Registra nuevo usuario</h3>
                </div>
                <div class="panel-body">
                    <?php echo $__env->make('axicasa.forms.usuarios.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="panel-footer">
                    <a href="/empleados" class="btn btn-danger">Cancelar</a>
                    <button type="submit" class="btn btn-primary pull-right">Registrar</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/usuarios/create.blade.php ENDPATH**/ ?>