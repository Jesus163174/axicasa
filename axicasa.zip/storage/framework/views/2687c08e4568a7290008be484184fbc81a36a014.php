<?php $__env->startSection('title','Registro de usuarios'); ?>
<?php $__env->startSection('breadcrum'); ?>
    <li><a href="/dashboard">Dashboard</a></li>
    <li class="active">Empleados</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('status_success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e(session('status_success')); ?></strong>
                </div>
            <?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Listado de empleados</h3>
                    <ul class="panel-controls">
                        <a href="/empleados/create" class="btn btn-primary btn-sm"><span class="fa fa-plus"></span> Registro</a>
                    </ul>
                </div>
                <div class="panel-body">
                    <table class="table datatable">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Apellidos</th>
                            <th>email</th>
                            <th>Fecha registro</th>
                            <th>Estatus</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($usuario->nombre); ?></td>
                                    <td><?php echo e($usuario->apellidos); ?></td>
                                    <td><?php echo e($usuario->email); ?></td>
                                    <td><?php echo e($usuario->created_at); ?></td>
                                    <th>
                                        <span class="label label-<?php echo e($usuario->estatus); ?>"><?php echo e($usuario->estatus); ?></span>
                                    </th>
                                    <td>
                                        <a href="/empleados/<?php echo e($usuario->id); ?>/edit" class="btn btn-primary btn-sm">Actualizar</a>
                                        <form action="<?php echo e(asset('empleados/'.$usuario->id)); ?>" class="form-inline" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('delete')); ?>

                                            <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/usuarios/index.blade.php ENDPATH**/ ?>