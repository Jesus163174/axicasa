<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Nombre del empleado</label>
            <input type="text" value="<?php echo e(old('nombre')); ?>" name="nombre" class="form-control <?php echo e($errors->has('nombre') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('nombre','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Apellidos del empleado</label>
            <input type="text" value="<?php echo e(old('apellidos')); ?>" name="apellidos" class="form-control <?php echo e($errors->has('apellidos') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('apellidos','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Correo electronico</label>
            <input type="email" value="<?php echo e(old('email')); ?>" name="email" class="form-control <?php echo e($errors->has('email') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Contraseña</label>
            <input type="password"  name="password" class="form-control <?php echo e($errors->has('password') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('password','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/forms/usuarios/form.blade.php ENDPATH**/ ?>