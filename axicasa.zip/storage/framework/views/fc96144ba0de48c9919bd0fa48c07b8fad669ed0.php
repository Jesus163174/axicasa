<?php $__env->startSection('title','Registro inmuebles'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/previewimage.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrum'); ?>
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/inmuebles">Inmuebles</a></li>
    <li class="active">Registro</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <?php if(session()->has('status_success')): ?>
                <div class="alert alert-success">
                    <strong><?php echo e(session('status_success')); ?></strong>
                </div>
            <?php endif; ?>
        </div>

        <div class="col-md-6">
            <div class="panel panel-primary">
                <div class="panel-heading flex">
                    <h5 class="title-panel"><?php echo e($inmueble->titulo); ?></h5>
                    <a data-toggle="modal" data-target=".bd-example-modal-lg" class="btn btn-primary"><i class="fa fa-edit"></i> Actualizar</a>
                </div>
                <div class="panel-body">
                    <img src="<?php echo e(asset('axicasa/'.$inmueble->portada)); ?>" style="width: 100%;" alt=""><hr>
                    <?php echo $inmueble->descripcion; ?>

                </div>
            </div>
        </div>
        <div class="col-md-6">
            <form action="<?php echo e(asset('inmuebles/caracteristicas/'.$inmueble->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo e(method_field('put')); ?>

                <div class="panel panel-primary">
                    <div class="panel-heading flex">
                        <h3 class="panel-title">Caracteristicas de la vivienda</h3>
                        <button type="submit" class="btn btn-primary"><span class="fa fa-plus"></span>Subir</button>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Costo: </label>
                                    <input type="text" value="<?php echo e($inmueble->costo); ?>" name="costo" class="form-control">
                                    <?php echo $errors->first('costo','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Tipo: </label>
                                    <select name="tipo" class="form-control" id="">
                                        <option value="<?php echo e($inmueble->tipo); ?>" selected>
                                            <?php if($inmueble->tipo == 'casa'): ?>
                                                1.Casa
                                            <?php else: ?>
                                                2.Departamento
                                            <?php endif; ?>
                                        </option>
                                        <option value="casa">1.Casa</option>
                                        <option value="departamento">2.Departamento</option>
                                    </select>
                                    <?php echo $errors->first('tipo','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Numero de habitaciones: </label>
                                    <input type="number" value="<?php echo e($inmueble->habitaciones); ?>" name="habitaciones" class="form-control">
                                    <?php echo $errors->first('habitaciones','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Area(M^2): </label>
                                    <input type="number" value="<?php echo e($inmueble->area); ?>" name="area" class="form-control">
                                    <?php echo $errors->first('area','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Estacionamiento:</label>
                                    <?php if($inmueble->estacionamiento == 0 || $inmueble->estacionamiento == 1 ): ?>
                                        <select name="estacionamiento" class="form-control" id="">
                                            <option value="<?php echo e($inmueble->estacionamiento); ?>" selected>
                                                <?php if($inmueble->estacionamiento == 0): ?>
                                                    1.Si
                                                <?php else: ?>
                                                    2.No
                                                <?php endif; ?>
                                            </option>
                                            <option value="0">1.Si</option>
                                            <option value="1">2.No</option>
                                        </select>
                                        <?php echo $errors->first('estacionamiento','<span class="help-block">:message</span>'); ?>

                                    <?php else: ?>
                                        <select name="estacionamiento" class="form-control" id="">
                                            <option value="<?php echo e($inmueble->estacionamiento); ?>" selected>¿Hay estacionamiento?</option>
                                            <option value="0">1.Si</option>
                                            <option value="1">2.No</option>
                                        </select>
                                        <?php echo $errors->first('estacionamiento','<span class="help-block">:message</span>'); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-6" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Numero de baños: </label>
                                    <input type="number" value="<?php echo e($inmueble->baños); ?>" name="baños" class="form-control">
                                    <?php echo $errors->first('baños','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                            <div class="col-md-12" style="margin-bottom: 15px;">
                                <div class="form-group-lg">
                                    <label for="">Numero de pisos: </label>
                                    <input type="number" value="<?php echo e($inmueble->pisos); ?>" name="pisos" class="form-control">
                                    <?php echo $errors->first('pisos','<span class="help-block">:message</span>'); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>

        </div>

    </div>
    <form action="<?php echo e(asset('inmuebles/'.$inmueble->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('put')); ?>

        <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><?php echo e($inmueble->titulo); ?> ( <span class="fa fa-edit"></span> Actualizar)</h4>
                    </div>
                    <div class="modal-body">
                        <label for="">Titulo: </label>
                        <input type="text" value="<?php echo e($inmueble->titulo); ?>" name="titulo" class="form-control"> <br>
                        <textarea class="summernote"  name="descripcion" placeholder="Ingresa una descripción">
                            <?php echo e($inmueble->descripcion); ?>

                        </textarea>
                    </div>
                    <div class="modal-footer">
                        <a href="" class="btn btn-info">Agregar fotos</a>
                        <button type="submit" class="btn btn-primary">Actualizar</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/previewimage.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/summernote/summernote.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/inmuebles/caracteristicas.blade.php ENDPATH**/ ?>