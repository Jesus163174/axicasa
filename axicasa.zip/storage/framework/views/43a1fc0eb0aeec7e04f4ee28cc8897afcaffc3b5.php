<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Nombre del empleado</label>
            <input type="text" value="<?php echo e($usuario->nombre); ?>" name="nombre" class="form-control <?php echo e($errors->has('nombre') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('nombre','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Apellidos del empleado</label>
            <input type="text" value="<?php echo e($usuario->apellidos); ?>" name="apellidos" class="form-control <?php echo e($errors->has('apellidos') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('apellidos','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
    <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12" style="margin-bottom: 20px;">
        <div class="form-group">
            <label for="">Correo electronico</label>
            <input type="email" value="<?php echo e($usuario->email); ?>" name="email" class="form-control <?php echo e($errors->has('email') ? 'has-error-input': ' '); ?>">
            <?php echo $errors->first('email','<span class="help-block">:message</span>'); ?>

        </div>
    </div>
</div>
<?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/forms/usuarios/form-edit.blade.php ENDPATH**/ ?>