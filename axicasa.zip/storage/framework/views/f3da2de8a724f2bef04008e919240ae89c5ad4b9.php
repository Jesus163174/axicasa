<?php $__env->startSection('title','Registro inmuebles'); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/previewimage.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrum'); ?>
    <li><a href="/dashboard">Dashboard</a></li>
    <li><a href="/inmuebles">Inmuebles</a></li>
    <li class="active">Registro</li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <form action="<?php echo e(asset('inmuebles')); ?>" enctype="multipart/form-data" method="post">
            <?php echo csrf_field(); ?>
            <div class="col-md-8">
                <div class="panel panel-primary">
                    <div class="panel-heading flex">
                        <h3 class="panel-title">Registrar nuevo</h3>
                        <button type="submit" class="btn btn-primary"><i class="fa fa-upload"></i> Subir</button>
                    </div>
                    <div class="panel-body">
                        <div class="form-group">
                            <label for="">Encabezado o titulo de la vivienda</label>
                            <input type="text" name="titulo" class="form-control input-lg">
                            <?php echo $errors->first('titulo','<span class="help-block">:message</span>'); ?>

                        </div>
                        <div>
                            <textarea class="summernote" name="descripcion" placeholder="Ingresa una descripción"></textarea>
                            <?php echo $errors->first('descripcion','<span class="help-block">:message</span>'); ?>

                        </div>


                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3 class="panel-title">Subir portada</h3>
                    </div>
                    <div class="panel-body avatar-upload">
                        <div class="avatar-edit">
                            <input type='file' name="portada" id="imageUpload" accept=".png, .jpg, .jpeg" />
                            <label for="imageUpload"></label>
                        </div>
                        <div class="avatar-preview">
                            <div id="imagePreview" style="background-image: url(https://images.pexels.com/photos/106399/pexels-photo-106399.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940);">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>

    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('js/previewimage.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/plugins/summernote/summernote.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\trabajo\inusual\axicasa\axicasa\resources\views/axicasa/inmuebles/create.blade.php ENDPATH**/ ?>